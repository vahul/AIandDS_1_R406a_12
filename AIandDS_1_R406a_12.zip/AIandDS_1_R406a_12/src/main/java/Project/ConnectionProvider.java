package Project;
import java.io.IOException;
import java.sql.*;
public class ConnectionProvider {
public static Connection getCon() throws IOException {
	try {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/event","root","2004");
		return con;
	}catch (Exception e) {
		  System.out.println(e);
		  return null;
	}
}
	
}